//
//  main.swift
//  Class Tutorial
//
//  Created by Ioannis Pavlidis on 9/9/20.
//  Copyright © 2020 Ioannis Pavlidis. All rights reserved.
//

class Bird {
    var isFemale = true
    
    func layEggs () {
        print("It does not give birth but lays eggs")
    }
    
    func fly() {
        print("It flies by flapping its wings")
    }
}

class Swift: Bird {
    func sleepInFlight() {
        print("It can sleep in flight")
    }
}

class Chicken: Bird {
    
}

class Airplane: Bird {
    
}

struct MagicKingdom {
    func airShow(flyingObject: Bird) {
        flyingObject.fly()
    }
}

print("\nHere's what a swift can do - behold!")
let swiftOne = Swift()
swiftOne.layEggs()
swiftOne.fly()
swiftOne.sleepInFlight()

print("\nHere's what a chicken can do - behold!")
let chickenOne = Chicken()
chickenOne.layEggs()
chickenOne.fly()

print("\nHere's what an airplane can do - behold!")
let airplaneOne = Airplane()
airplaneOne.layEggs()
airplaneOne.fly()

print("\nHere's what the air exhibit in Houston's Magic Kingdom does!")
let houstonMagicKingdom = MagicKingdom()
houstonMagicKingdom.airShow(flyingObject: airplaneOne)
