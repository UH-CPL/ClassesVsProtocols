//
//  main.swift
//  Protocols Tutorial
//
//  Created by Ioannis Pavlidis on 9/9/20.
//  Copyright © 2020 Ioannis Pavlidis. All rights reserved.
//

protocol canFly {
    func fly()
}

class Bird {
    func layEggs() {
        print("It does not give birth but lays eggs")
    }
}

class Swift: Bird, canFly {
    func fly() {
        print("It flies by flapping its wings")
    }
    
    func sleepInFlight() {
        print("It can sleep in flight")
    }
}

class Chicken: Bird {
    
}

class Airplane: canFly {
    func fly() {
        print("It flies using its engine")
    }
}

struct MagicKingdom {
    func airShow(flyingObject: Airplane) {
        flyingObject.fly()
    }
}

print("\nHere's what a swift can do")
let swiftOne = Swift()
swiftOne.layEggs()
swiftOne.fly()
swiftOne.sleepInFlight()

print("\nHere's what a chicken can do")
let chickenOne = Chicken()
chickenOne.layEggs()

print("\nHers' what an airplane can do")
let airplaneOne = Airplane()
airplaneOne.fly()

print("\nHere's what the flying object in Houston's Air Show does")
let houstonMagicKingdom = MagicKingdom()
houstonMagicKingdom.airShow(flyingObject: airplaneOne)
